package Assignment_2;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		
		
		//reversing linkedList demo
		JerryLinkedList testList = new JerryLinkedList();	//create linkedList and add elements and print
		testList.addNode(0);
		testList.addNode(1);
		testList.addNode(2);
		testList.addNode(3);
		testList.addNode(4);
		System.out.println(testList);
				
		testList.reverse();					//reverse linkedList and print
		System.out.println(testList);
		System.out.println();
		
		
		//CustomQStack demo
		Queue<Integer> myQueue = new LinkedList<Integer>();		//create a queue
		for(int i = 0; i < 10; i++) {
			myQueue.add(i);
		} 
		System.out.println(myQueue);
		CustomQStack customStack = new CustomQStack(myQueue);	//turn queue into customStack
		
		Integer x = customStack.pop();		//pop and print top element
		System.out.println(x);
		
		x = customStack.pop();		//pop and print top element
		System.out.println(x);
		
		System.out.println(customStack.empty());		//check if empty
		
		customStack.push(1);					//add 1 to the back and print list
		System.out.println(customStack);
		
		x = customStack.pop();		//pop and print top element
		System.out.println(x);
		
		System.out.println(customStack);		//print final stack
		
		Queue<Integer> emptyQueue = new LinkedList<Integer>();			//create an empty customQStack
		CustomQStack emptyQStack = new CustomQStack(emptyQueue);	
		System.out.println(emptyQStack.pop());							//test to see popping when empty
		
		System.out.println();
		
		
		//CustomSQueue demo
		Stack<Integer> myStack = new Stack<Integer>();		//create a stack and print
		for (int i = 0; i < 10; i++) {
			myStack.push(i);
		}
		CustomSQueue customQueue = new CustomSQueue(myStack);	//turn stack into queue and print
		System.out.println(customQueue);
		
		x = customQueue.poll();		//poll and print first element twice
		System.out.println(x);
		x = customQueue.poll();
		System.out.println(x);
		
		customQueue.add(2);					//add two to the end
		System.out.println(customQueue);
		
		Stack<Integer> emptyStack = new Stack<Integer>();			//create empty customSQueue
		CustomSQueue emptySQueue = new CustomSQueue(emptyStack);
		System.out.println(emptySQueue.poll());						//test to see polling when empty
	}

}
