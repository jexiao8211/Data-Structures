package Assignment_1;

public class Main {

	public static void main(String[] args) {
		CourseList testList = new CourseList();
		
		
		testList.addCourse(0, new Course("CSDS233", "Data Structures", 50));
		testList.addCourse(0, new Course("MATH223", "Calc 3", 40));
		testList.addCourse(0, new Course("FSSY185R", "Children's Books", 30));
		testList.addCourse(4, new Course("CLSS444", "Another Class", 90));
			
		testList.removeCourse(0);
		testList.removeCourse(2);					
		testList.removeCourse(9);						//fails
		
		testList.addCourse(0, new Course("FSSY185R", "Children's Books", 30));
		testList.addCourse(4, new Course("CLSS444", "Another Class", 90));
		
		testList.changeCapacity("FSSY185R", 999);
		testList.changeCapacity("CLSS444", 4000000);
		testList.changeCapacity("DNE", 2);				//fails
		
		testList.getCourseWithIndex(0);
		testList.getCourseWithIndex(1);
		testList.getCourseWithIndex(3);
		testList.getCourseWithIndex(4);  //fails
		
		testList.searchCourseID("FSSY185R");
		testList.searchCourseID("MATH223");
		testList.searchCourseID("CLSS444");
		testList.searchCourseID("DNE");		//fails
		
		testList.searchCourseName("Children's Books");
		testList.searchCourseName("Calc 3");
		testList.searchCourseName("Another Class");
		testList.searchCourseName("DNE");			//fails
		
	}

}
